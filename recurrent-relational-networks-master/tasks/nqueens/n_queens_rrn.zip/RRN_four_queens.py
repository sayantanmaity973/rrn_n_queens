import os
from typing import Tuple
import csv

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.data import Dataset, Iterator
from tensorflow.nn import softmax
from tensorflow.python.ops.rnn_cell import LSTMCell

import sys
sys.path.insert(0, '../../')
import util
from message_passing import message_passing
from model import Model

class NQueensRecurrentRelationalNet(Model):
    devices = util.get_devices()
    batch_size = 16
    revision = os.environ.get('REVISION')
    message = os.environ.get('MESSAGE')
    emb_size = 16
    n_steps = 32
    edge_keep_prob = 1.0
    n_hidden = 96
    edges = 'n_queens'

    def __init__(self, train_csv: str, valid_csv: str, test_csv: str):
        super().__init__()
        #print ('Hola')
        #model = RecurrentRelationalNetwork(train_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/train.csv", valid_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/valid.csv", test_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/test.csv")
        train_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/train.csv"; 
        valid_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/valid.csv"; 
        test_csv="//wsl.localhost/Ubuntu/home/rik/recurrent-relational-networks-master/tasks/4queens/test.csv"
        self.train_csv = train_csv
        self.valid_csv = valid_csv
        self.test_csv = test_csv
        #self.train, self.valid, self.test = self.encode.data()
        
        with tf.Graph().as_default(), tf.device('/cpu:0'):
        
            regularizer = tf.keras.regularizers.L2(1e-4)
            self.name = f"{self.revision} {self.message}"
            self.train, self.valid, self.test = self.load_csv(self.train_csv, self.valid_csv, self.test_csv)

            print("Building graph...")
            self.session = tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(allow_soft_placement=True))
            self.global_step = tf.Variable(initial_value=0, trainable=False)
            self.optimizer = tf.optimizers.Adam(learning_rate=2e-4)

            self.mode = tf.compat.v1.placeholder(tf.string)

            if self.edges == 'n_queens':
                edges = self.n_queens_edges()
            elif self.edges == 'full':
                edges = [(i, j) for i in range(16) for j in range(16) if not i == j]
            else:
                raise ValueError('edges must be n_queens or full')

            edge_indices = tf.constant([(i + (b * 4), j + (b * 4)) for b in range(self.batch_size) for i, j in edges], tf.int32)
            n_edges = tf.shape(edge_indices)[0]
            edge_features = tf.zeros((n_edges, 1), tf.float32)
            positions = tf.constant([[(i, j) for i in range(4) for j in range(4)] for b in range(self.batch_size)], tf.int32)  # (bs, 16, 2)
            rows = layers.Embedding(4, self.emb_size, input_length=16, name='row-embeddings', embeddings_regularizer=regularizer)(positions[:, :, 0])  # bs, 16, emb_size
            cols = layers.Embedding(4, self.emb_size, input_length=16, name='cols-embeddings', embeddings_regularizer=regularizer)(positions[:, :, 1])  # bs, 16, emb_size

            def avg_n(x):
                return tf.reduce_mean(tf.stack(x, axis=0), axis=0)

            towers = []
            with tf.compat.v1.variable_scope(tf.compat.v1.get_variable_scope()):
                for device_nr, device in enumerate(self.devices):
                    with tf.device('/cpu:0'):

                        if self.is_testing:
                            (quizzes, answers), edge_keep_prob = self.test.get_next(), 1.0
                        else:
                            (quizzes, answers), edge_keep_prob = tf.cond(
                                tf.equal(self.mode, "train"),
                                true_fn=lambda: (self.train.get_next(), self.edge_keep_prob),
                                false_fn=lambda: (self.valid.get_next(), 1.0)
                            )

                        x = layers.Embedding(5, self.emb_size, input_length=16, name='nr-embeddings', embeddings_regularizer=regularizer)(quizzes)  # bs, 16, emb_size
                        x = tf.concat([x, rows, cols], axis=2)
                        x = tf.reshape(x, (-1, 3 * self.emb_size))

                    with tf.device(device), tf.compat.v1.name_scope("device-%s" % device_nr):

                        def mlp(x, scope):
                            with tf.compat.v1.variable_scope(scope):
                                for i in range(3):
                                    x = layers.Dense(self.n_hidden, activation='relu', kernel_regularizer=regularizer)(x)
                                return layers.Dense(self.n_hidden, activation=None, kernel_regularizer=regularizer)(x)

                        x = mlp(x, 'pre-fn')
                        x0 = x
                        n_nodes = tf.shape(x)[0]
                        outputs = []
                        log_losses = []
                        with tf.compat.v1.variable_scope('steps'):
                            lstm_cell = LSTMCell(self.n_hidden)
                            state = lstm_cell.zero_state(n_nodes, tf.float32)

                            for step in range(self.n_steps):
                                x = message_passing(x, edge_indices, edge_features, lambda x: mlp(x, 'message-fn'), edge_keep_prob)
                                x = mlp(tf.concat([x, x0], axis=1), 'post-fn')
                                x, state = lstm_cell(x, state)

                                with tf.compat.v1.variable_scope('graph-sum'):
                                    out = layers.Dense(5, activation=None)(x)
                                    out = tf.reshape(out, (-1, 16, 5))
                                    outputs.append(out)
                                    log_losses.append(tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=answers, logits=out)))

                                tf.compat.v1.get_variable_scope().reuse_variables()

                        reg_loss = sum(tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.REGULARIZATION_LOSSES))
                        loss = avg_n(log_losses) + reg_loss

                        towers.append({
                            'loss': loss,
                            'grads': self.optimizer.compute_gradients(loss),
                            'log_losses': tf.stack(log_losses),  # (n_steps, 1)
                            'quizzes': quizzes,  # (bs, 16, 5)
                            'answers': answers,  # (bs, 16, 5)
                            'outputs': tf.stack(outputs)  # n_steps, bs, 16, 5
                        })

                        tf.compat.v1.get_variable_scope().reuse_variables()

            self.loss = avg_n([t['loss'] for t in towers])
            self.out = tf.concat([t['outputs'] for t in towers], axis=1)  # n_steps, bs, 16, 5
            self.predicted = tf.cast(tf.argmax(self.out, axis=3), tf.int32)
            self.answers = tf.concat([t['answers'] for t in towers], axis=0)
            self.quizzes = tf.concat([t['quizzes'] for t in towers], axis=0)

            tf.compat.v1.summary.scalar('losses/total', self.loss)
            tf.compat.v1.summary.scalar('losses/reg', reg_loss)
            log_losses = avg_n([t['log_losses'] for t in towers])

            for step in range(self.n_steps):
                equal = tf.equal(self.answers, self.predicted[step])

                digit_acc = tf.reduce_mean(tf.cast(equal, tf.float32))
                tf.compat.v1.summary.scalar('steps/%d/digit-acc' % step, digit_acc)

                puzzle_acc = tf.reduce_mean(tf.cast(tf.reduce_all(equal, axis=1), tf.float32))
                tf.compat.v1.summary.scalar('steps/%d/puzzle-acc' % step, puzzle_acc)

                tf.compat.v1.summary.scalar('steps/%d/losses/log' % step, log_losses[step])

            avg_gradients = util.average_gradients([t['grads'] for t in towers])
            self.train_step = self.optimizer.apply_gradients(avg_gradients, global_step=self.global_step)

            self.session.run(tf.compat.v1.global_variables_initializer())
            self.saver = tf.compat.v1.train.Saver()
            util.print_vars(tf.compat.v1.trainable_variables())

            self.train_writer = tf.compat.v1.summary.FileWriter('/tmp/tensorboard/n_queens/%s/train/%s' % (self.revision, self.name), self.session.graph)
            self.test_writer = tf.compat.v1.summary.FileWriter('/tmp/tensorboard/n_queens/%s/test/%s' % (self.revision, self.name), self.session.graph)
            self.summaries = tf.compat.v1.summary.merge_all()

    def n_queens_edges(self) -> list[Tuple[int, int]]:
        def cross(a):
            return [(i, j) for i in a.flatten() for j in a.flatten() if not i == j]

        idx = np.arange(16).reshape(4, 4)
        rows, columns, squares = [], [], []
        for i in range(4):
            rows += cross(idx[i, :])
            columns += cross(idx[:, i])
        for i in range(2):
            for j in range(2):
                squares += cross(idx[i * 2:(i + 1) * 2, j * 2:(j + 1) * 2])
        return list(set(rows + columns + squares))


    def load_csv(self, train_csv: str, valid_csv: str, test_csv: str) -> Tuple[Iterator, Iterator, Iterator]:
        def parse_csv(file_path):
            data = np.loadtxt(file_path, delimiter=",", dtype=np.int32)
            return data[:, :-1], data[:, -1]

        train_data = parse_csv(train_csv)
        valid_data = parse_csv(valid_csv)
        test_data = parse_csv(test_csv)

        train = Dataset.from_tensor_slices(train_data).shuffle(self.batch_size * 10).repeat(-1).batch(self.batch_size).make_one_shot_iterator()
        valid = Dataset.from_tensor_slices(valid_data).shuffle(self.batch_size * 10).repeat(-1).batch(self.batch_size).make_one_shot_iterator()
        test = Dataset.from_tensor_slices(test_data).shuffle(self.batch_size * 10).repeat(1).batch(self.batch_size).make_one_shot_iterator()

        return train, valid, test
    

    '''
    def load_csv(self, train_csv, valid_csv, test_csv) -> Tuple[Iterator, Iterator, Iterator]:
        def load_and_encode(csv_file):
            data = np.loadtxt(csv_file, delimiter=',')
            features = data[:, :-1]
            labels = data[:, -1]
            return Dataset.from_tensor_slices((features, labels))

        print("Loading and encoding data...")
        train = load_and_encode(train_csv).shuffle(self.batch_size * 10).repeat().batch(self.batch_size).make_one_shot_iterator()
        valid = load_and_encode(valid_csv).repeat().batch(self.batch_size).make_one_shot_iterator()
        test = load_and_encode(test_csv).batch(self.batch_size).make_one_shot_iterator()

        return train, valid, test

    '''



    def save(self, name: str):
        self.saver.save(self.session, name)

    def load(self, name: str):
        print("Loading %s..." % name)
        self.saver.restore(self.session, name)

    def train_batch(self) -> float:
        _, _loss, _logits, _summaries, _step = self.session.run([self.train_step, self.loss, self.out, self.summaries, self.global_step], {self.mode: 'train'})
        if _step % 1000 == 0:
            self.train_writer.add_summary(_summaries, _step)

        return _loss

    def test_batch(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        _quizzes, _logits, _answers = self.session.run([self.quizzes, self.out, self.answers], {self.mode: 'foo'})
        return _quizzes, _logits, _answers

    def val_batch(self) -> float:
        _loss, _predicted, _answers, _summaries, _step = self.session.run([self.loss, self.predicted, self.answers, self.summaries, self.global_step], {self.mode: 'valid'})
        self.test_writer.add_summary(_summaries, _step)
        return _loss
