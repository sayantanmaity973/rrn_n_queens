'''
import os
import sys
import numpy as np
import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.data import Dataset
from tensorflow.contrib.data import Iterator
from tensorflow.contrib.rnn import LSTMCell

sys.path.insert(0, '../../')
import util
from message_passing import message_passing
from model import Model
from tasks.nqueens.data import nqueens

class NQueensRecurrentRelationalNet(Model):
    # Define your model parameters and configurations here
    ...

    def __init__(self, is_testing):
        super().__init__()
        # Define your model initialization logic here
        ...

    def encode_data(self, data):
        # Define how to encode the N-Queens data for training, validation, and testing
        ...

    def train_batch(self):
        # Define how to perform one training step
        ...

    def test_batch(self):
        # Define how to test the model
        ...

    def val_batch(self):
        # Define how to perform validation
        ...

# You can define other necessary functions and classes here

def main():
    # Create an instance of the NQueensRecurrentRelationalNet model
    model = NQueensRecurrentRelationalNet(is_testing=False)

    # Train the model using the trainer module
    trainer.train(model)

if __name__ == "__main__":
    main()



'''


#from tasks.queens.rrn import NQueensRecurrentRelationalNet
from rrn import NQueensRecurrentRelationalNet
import trainer

# Create an instance of the QueensRecurrentRelationalNet model
nqueens_model = NQueensRecurrentRelationalNet(False)

# Start training the model
trainer.train(nqueens_model)